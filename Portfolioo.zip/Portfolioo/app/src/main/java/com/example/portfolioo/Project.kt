package com.example.portfolioo

class Project(
    val name: String,
    val description: String,
    val github: String,
    val imageSrc: Int
) {
}